package vn.softz.app.einvoicehub.provider.bkav.mapper;

import org.springframework.stereotype.Component;
import vn.softz.app.einvoicehub.provider.bkav.model.BkavInvoice;
import vn.softz.app.einvoicehub.provider.model.InvoiceAttachmentData;
import vn.softz.app.einvoicehub.provider.model.InvoiceData;
import vn.softz.app.einvoicehub.provider.model.InvoiceDetailData;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class BkavDataMapper {
    
    private static final DateTimeFormatter BKAV_DATE_FORMATTER = DateTimeFormatter
            .ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
            .withZone(ZoneId.systemDefault());
    
    public BkavInvoice.RequestData toBkavRequestData(InvoiceData invoiceData) {
        if (invoiceData == null) {
            return null;
        }
        
        Long partnerId = parsePartnerInvoiceId(invoiceData.getPartnerInvoiceId());
        if (partnerId == null || partnerId <= 0) {
            partnerId = System.currentTimeMillis();
        }
        
        String partnerStringId = invoiceData.getPartnerInvoiceStringId();
        if (partnerStringId == null) {
            partnerStringId = "";
        }
        
        return BkavInvoice.RequestData.builder()
                .invoice(toBkavHeader(invoiceData))
                .listInvoiceDetailsWS(toBkavDetailList(invoiceData.getDetails()))
                .listInvoiceAttachFileWS(toBkavAttachmentList(invoiceData.getAttachments()))
                .partnerInvoiceID(partnerId)
                .partnerInvoiceStringID(partnerStringId)
                .build();
    }

    private BkavInvoice.Header toBkavHeader(InvoiceData data) {
        return BkavInvoice.Header.builder()
                .invoiceTypeID(data.getInvoiceTypeId() != null ? data.getInvoiceTypeId() : 1)
                .invoiceDate(formatBkavDate(data.getInvoiceDate()))
                .buyerName(data.getBuyerName())
                .buyerTaxCode(data.getBuyerTaxCode() != null ? data.getBuyerTaxCode() : "")
                .buyerUnitName(data.getBuyerUnitName() != null ? data.getBuyerUnitName() : "")
                .buyerAddress(data.getBuyerAddress() != null ? data.getBuyerAddress() : "")
                .buyerBankAccount(data.getBuyerBankAccount() != null ? data.getBuyerBankAccount() : "")
                .payMethodID(data.getPayMethodId() != null ? data.getPayMethodId() : 3)
                .receiveTypeID(data.getReceiveTypeId() != null ? data.getReceiveTypeId() : 3)
                .receiverEmail(data.getReceiverEmail() != null ? data.getReceiverEmail() : "")
                .receiverMobile(data.getReceiverMobile() != null ? data.getReceiverMobile() : "")
                .receiverAddress(data.getReceiverAddress() != null ? data.getReceiverAddress() : "")
                .receiverName(data.getReceiverName() != null ? data.getReceiverName() : "")
                .note(data.getNotes() != null ? data.getNotes() : "")
                .userDefine(data.getUserDefine() != null ? data.getUserDefine() : "")
                .billCode(data.getBillCode() != null ? data.getBillCode() : "")
                .currencyID(data.getCurrencyCode() != null ? data.getCurrencyCode() : "VND")
                .exchangeRate(data.getExchangeRate() != null ? data.getExchangeRate().doubleValue() : 1.0)
                .invoiceForm(data.getInvoiceForm() != null ? data.getInvoiceForm() : "1")
                .invoiceSerial(data.getInvoiceSerial() != null ? data.getInvoiceSerial() : "")
                .invoiceNo(data.getInvoiceNo() != null ? data.getInvoiceNo() : 0)
                .build();
    }

    private List<BkavInvoice.Detail> toBkavDetailList(List<InvoiceDetailData> details) {
        if (details == null || details.isEmpty()) {
            return new ArrayList<>();
        }
        return details.stream()
                .map(this::toBkavDetail)
                .collect(Collectors.toList());
    }

    private BkavInvoice.Detail toBkavDetail(InvoiceDetailData detail) {
        return BkavInvoice.Detail.builder()
                .itemTypeID(detail.getItemTypeId() != null ? detail.getItemTypeId() : 0)
                .itemCode(detail.getItemCode() != null ? detail.getItemCode() : "")
                .itemName(detail.getItemName())
                .unitName(detail.getUnitName())
                .qty(detail.getQuantity() != null ? detail.getQuantity() : java.math.BigDecimal.ZERO)
                .price(detail.getPrice() != null ? detail.getPrice() : java.math.BigDecimal.ZERO)
                .amount(detail.getAmount() != null ? detail.getAmount() : java.math.BigDecimal.ZERO)
                .taxRateID(detail.getTaxRateId() != null ? detail.getTaxRateId() : 3)
                .taxRate(detail.getTaxRate() != null ? detail.getTaxRate() : java.math.BigDecimal.TEN)
                .taxAmount(detail.getTaxAmount() != null ? detail.getTaxAmount() : java.math.BigDecimal.ZERO)
                .discountRate(detail.getDiscountRate() != null ? detail.getDiscountRate() : java.math.BigDecimal.ZERO)
                .discountAmount(detail.getDiscountAmount() != null ? detail.getDiscountAmount() : java.math.BigDecimal.ZERO)
                .isDiscount(detail.getIsDiscount() != null ? detail.getIsDiscount() : false)
                .userDefineDetails(detail.getUserDefineDetails() != null ? detail.getUserDefineDetails() : "")
                .isIncrease(detail.getIsIncrease() != null ? detail.getIsIncrease() : false)
                .build();
    }

    private List<BkavInvoice.Attachment> toBkavAttachmentList(List<InvoiceAttachmentData> attachments) {
        if (attachments == null || attachments.isEmpty()) {
            return new ArrayList<>();
        }
        return attachments.stream()
                .map(this::toBkavAttachment)
                .collect(Collectors.toList());
    }

    private BkavInvoice.Attachment toBkavAttachment(InvoiceAttachmentData attachment) {
        return BkavInvoice.Attachment.builder()
                .attachName(attachment.getFileName())
                .attachData(attachment.getFileContent())
                .attachDescription("")
                .build();
    }

    private Long parsePartnerInvoiceId(String partnerInvoiceId) {
        if (partnerInvoiceId == null || partnerInvoiceId.isEmpty()) {
            return 0L;
        }
        try {
            return Long.parseLong(partnerInvoiceId);
        } catch (NumberFormatException e) {
            return 0L;
        }
    }
    
    private String formatBkavDate(Instant instant) {
        if (instant == null) {
            instant = Instant.now();
        }
        return BKAV_DATE_FORMATTER.format(instant);
    }
}
